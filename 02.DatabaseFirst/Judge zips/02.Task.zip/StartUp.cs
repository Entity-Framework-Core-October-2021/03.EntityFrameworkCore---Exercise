﻿using SoftUni.Data;
using System;
using System.Linq;
using System.Text;

namespace SoftUni
{
    class StartUp
    {
        public static void Main(string[] args)
        {
            var context = new SoftUniContext();
            Console.WriteLine(GetEmployeesFullInformation(context));
        }
        public static string GetEmployeesFullInformation(SoftUniContext context)
        {
            using (context)
            {
                var employees = context.Employees.ToList().OrderBy(x=>x.EmployeeId);
                StringBuilder sb = new StringBuilder();

                foreach (var employee in employees)
                {
                    sb.Append($"{employee.FirstName} {employee.LastName} {employee.MiddleName} {employee.JobTitle} {employee.Salary:F2}");
                    sb.AppendLine();
                }

                return sb.ToString().TrimEnd();
            }
        }
    }
}
