﻿using SoftUni.Data;
using SoftUni.Models;
using System;
using System.Linq;
using System.Text;

namespace SoftUni
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            using SoftUniContext context = new SoftUniContext();

            //string result = GetEmployeesFullInformation(context); //- 03
            //string result = GetEmployeesWithSalaryOver50000(context); //- 04
            //string result = GetEmployeesFromResearchAndDevelopment(context); //- 05
            string result = AddNewAddressToEmployee(context); //- 06

            Console.WriteLine(result);
        }

        //03. Employees Full Information
        public static string GetEmployeesFullInformation(SoftUniContext context)
        {
            var employees = context.Employees
                                   .Select(e => new
                                    {
                                        e.FirstName,
                                        e.LastName,
                                        e.MiddleName,
                                        e.JobTitle,
                                        e.Salary
                                    })
                                   .ToList();

                StringBuilder sb = new StringBuilder();

                foreach (var employee in employees)
                {
                    sb.AppendLine($"{employee.FirstName} {employee.LastName} {employee.MiddleName} {employee.JobTitle} {employee.Salary:F2}");
                }

                return sb.ToString().TrimEnd();
        }

        //04. Employees with Salary Over 50 000
        public static string GetEmployeesWithSalaryOver50000(SoftUniContext context)
        {
            var employees = context.Employees
                                   .Select(e => new
                                   {
                                       e.FirstName,
                                       e.Salary
                                   })
                                   .Where(e => e.Salary > 50000)
                                   .OrderBy(e=>e.FirstName)
                                   .ToList();

            StringBuilder sb = new StringBuilder();

            foreach (var employee in employees)
            {
                sb.AppendLine($"{employee.FirstName} - {employee.Salary:F2}");
            }

            return sb.ToString().TrimEnd();
        }

        //05. Employees from Research and Development
        public static string GetEmployeesFromResearchAndDevelopment(SoftUniContext context)
        {
            var employees = context.Employees
                                   .Where(e => e.Department.Name == "Research and Development")
                                   .OrderBy(e => e.Salary)
                                   .ThenByDescending(e => e.FirstName)
                                   .Select(e => new
                                   {
                                       e.FirstName,
                                       e.LastName,
                                       DepartmentName = e.Department.Name,
                                       e.Salary
                                   })
                                   .ToList();

            StringBuilder sb = new StringBuilder();

            foreach (var employee in employees)
            {
                sb.AppendLine($"{employee.FirstName} {employee.LastName} from {employee.DepartmentName} - ${employee.Salary:F2}");
            }
             
            return sb.ToString().TrimEnd();
        }

        //06. Adding a New Address and Updating Employee
        public static string AddNewAddressToEmployee(SoftUniContext context)
        {
            Address newAddress = new Address()
            {
                AddressText = "Vitoshka 15",
                TownId = 4
            };
            context.Addresses.Add(newAddress);

            var nakov = context.Employees.First(e=>e.LastName=="Nakov");
            nakov.Address = newAddress;

            context.SaveChanges();

            var employees = context.Employees
                                   .OrderByDescending(e=>e.AddressId)
                                   .Select(e => new
                                   {
                                       AddressText = e.Address.AddressText
                                   })
                                   .Take(10);

            StringBuilder sb = new StringBuilder();

            foreach (var employee in employees)
            {
                sb.AppendLine($"{employee.AddressText}");
            }

            return sb.ToString().TrimEnd();
        }
    }
}
