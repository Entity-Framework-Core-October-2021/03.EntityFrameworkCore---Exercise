﻿using SoftUni.Data;
using SoftUni.Models;
using System;
using System.Globalization;
using System.Linq;
using System.Text;

namespace SoftUni
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            using SoftUniContext context = new SoftUniContext();

            //string result = GetEmployeesFullInformation(context); //- 03
            //string result = GetEmployeesWithSalaryOver50000(context); //- 04
            //string result = GetEmployeesFromResearchAndDevelopment(context); //- 05
            //string result = AddNewAddressToEmployee(context); //- 06
            //string result = GetEmployeesInPeriod(context); //- 07
            string result = GetAddressesByTown(context); //- 08

            Console.WriteLine(result);
        }

        //03. Employees Full Information
        public static string GetEmployeesFullInformation(SoftUniContext context)
        {
            var employees = context.Employees
                                   .Select(e => new
                                   {
                                       e.FirstName,
                                       e.LastName,
                                       e.MiddleName,
                                       e.JobTitle,
                                       e.Salary
                                   })
                                   .ToList();

            StringBuilder sb = new StringBuilder();

            foreach (var employee in employees)
            {
                sb.AppendLine($"{employee.FirstName} {employee.LastName} {employee.MiddleName} {employee.JobTitle} {employee.Salary:F2}");
            }

            return sb.ToString().TrimEnd();
        }

        //04. Employees with Salary Over 50 000
        public static string GetEmployeesWithSalaryOver50000(SoftUniContext context)
        {
            var employees = context.Employees
                                   .Select(e => new
                                   {
                                       e.FirstName,
                                       e.Salary
                                   })
                                   .Where(e => e.Salary > 50000)
                                   .OrderBy(e => e.FirstName)
                                   .ToList();

            StringBuilder sb = new StringBuilder();

            foreach (var employee in employees)
            {
                sb.AppendLine($"{employee.FirstName} - {employee.Salary:F2}");
            }

            return sb.ToString().TrimEnd();
        }

        //05. Employees from Research and Development
        public static string GetEmployeesFromResearchAndDevelopment(SoftUniContext context)
        {
            var employees = context.Employees
                                   .Where(e => e.Department.Name == "Research and Development")
                                   .OrderBy(e => e.Salary)
                                   .ThenByDescending(e => e.FirstName)
                                   .Select(e => new
                                   {
                                       e.FirstName,
                                       e.LastName,
                                       DepartmentName = e.Department.Name,
                                       e.Salary
                                   })
                                   .ToList();

            StringBuilder sb = new StringBuilder();

            foreach (var employee in employees)
            {
                sb.AppendLine($"{employee.FirstName} {employee.LastName} from {employee.DepartmentName} - ${employee.Salary:F2}");
            }

            return sb.ToString().TrimEnd();
        }

        //06. Adding a New Address and Updating Employee
        public static string AddNewAddressToEmployee(SoftUniContext context)
        {
            Address newAddress = new Address()
            {
                AddressText = "Vitoshka 15",
                TownId = 4
            };
            context.Addresses.Add(newAddress);

            var nakov = context.Employees.First(e => e.LastName == "Nakov");
            nakov.Address = newAddress;

            context.SaveChanges();

            var employees = context.Employees
                                   .OrderByDescending(e => e.AddressId)
                                   .Select(e => new
                                   {
                                       AddressText = e.Address.AddressText
                                   })
                                   .Take(10);

            StringBuilder sb = new StringBuilder();

            foreach (var employee in employees)
            {
                sb.AppendLine($"{employee.AddressText}");
            }

            return sb.ToString().TrimEnd();
        }

        //07. Employees and Projects
        public static string GetEmployeesInPeriod(SoftUniContext context)
        {
            var employees = context.Employees
                                   .Where(e => e.EmployeesProjects.Any(ep => ep.Project.StartDate.Year >= 2001 && ep.Project.StartDate.Year <= 2003))
                                   .Take(10)
                                   .Select(e => new
                                   {
                                       e.FirstName,
                                       e.LastName,
                                       ManagerFirstName = e.Manager.FirstName,
                                       ManagerLastName = e.Manager.LastName,
                                       Projects = e.EmployeesProjects
                                                   .Select(ep => new
                                                   {
                                                       ProjectName = ep.Project.Name,
                                                       StartDate = ep.Project.StartDate.ToString("M/d/yyyy h:mm:ss tt", CultureInfo.InvariantCulture),
                                                       EndDate = ep.Project.EndDate.HasValue ? ep
                                                                                               .Project
                                                                                               .EndDate
                                                                                               .Value
                                                                                               .ToString("M/d/yyyy h:mm:ss tt", CultureInfo.InvariantCulture)
                                                                                               : "not finished"
                                                   })
                                   })
                                   .ToList();

            StringBuilder sb = new StringBuilder();

            foreach (var employee in employees)
            {
                sb.AppendLine($"{employee.FirstName} {employee.LastName} - Manager: {employee.ManagerFirstName} {employee.ManagerLastName}");

                foreach (var project in employee.Projects)
                {
                    sb.AppendLine($"--{project.ProjectName} - {project.StartDate} - {project.EndDate}");
                }
            }

            return sb.ToString().TrimEnd();
        }

        //08. Addresses by Town
        public static string GetAddressesByTown(SoftUniContext context)
        {
            var addresses = context.Addresses
                                   .Select(a => new
                                   {
                                       a.AddressText,
                                       TownName = a.Town.Name,
                                       EmployeesCount = a.Employees.Count
                                   })
                                   .OrderByDescending(a => a.EmployeesCount)
                                   .ThenBy(t => t.TownName)
                                   .ThenBy(at => at.AddressText)
                                   .Take(10);

            StringBuilder sb = new StringBuilder();

            foreach (var address in addresses)
            {
                sb.AppendLine($"{address.AddressText}, {address.TownName} - {address.EmployeesCount} employees");
            }

            return sb.ToString().TrimEnd();
        }
    }
}